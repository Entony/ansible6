# Ansible Collection - my_own_namespace.yandex_cloud_elk

Коллекция содержит модуль "my_own_module" и роль "my_own_role" для создания текстового файла на целевом хосте.

Пример использования:

```
yaml
• name: Run my_own_role
hosts: localhost
roles:
	• role: my_own_namespace.yandex_cloud_elk.my_own_role
vars:
path: /tmp/test.txt
content: "Hello world"
```